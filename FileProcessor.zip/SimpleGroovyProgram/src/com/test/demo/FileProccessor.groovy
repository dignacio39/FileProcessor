package com.test.demo
import groovy.io.FileType
import java.text.SimpleDateFormat


//Class to process files inside a folder and its sub-folder limited to text document only
class FileProccessor {

	def ProcessFiles(String baseDirectory, String searchText, String replaceText, boolean report=false ) {
		
		//Directory for the text file to be search/process
		def currentDir = new File(baseDirectory);
		
		//Variable for the log file
		def logFile;
		def logFilePath = "C:\\Users\\Darwin\\eclipse-workspace\\SimpleGroovyProgram\\src\\com\\test\\demo\\logs\\";
		
		//Variable for the backup file
		def backupFile;
		def backupFilePath = "C:\\Users\\Darwin\\eclipse-workspace\\SimpleGroovyProgram\\src\\com\\test\\demo\\ProcessedFilesBackup\\";
		
		//Variable to store all the text in a file
		def fileText;
		
		//Replace the contents of the list below with the
		//extensions to search for limited to .txt only
		def exts = [".txt"]
		
		def startTime = logTimeFormat();
		def endTime = logTimeFormat();
		
		//Variable for all the name of edited files
		def editedFiles= "Start Time: " + startTime + "\n";
		
		println "$startTime Processing..."
		currentDir.eachFileRecurse(
			{file ->
			  for (ext in exts){
				//Filter out the files with the valid extension and contains the word to be replaced
				if (file.name.endsWith(ext) && file.text.contains(searchText)) {
				  fileText = file.text;
				  //Back up the file before the process of replacing the word
				  backupFile = new File(backupFilePath+ "\\"+ logTime() +"-"+ file.name + ".bak");
				  backupFile.write(fileText);
				  //Replace the word after backup
				  fileText = fileText.replaceAll(searchText, replaceText)
				  file.write(fileText);
				  println "$file.name processed successfully!"
				  //Get all the file names thats been processed
				  editedFiles = editedFiles + file.name + "\n";
				}
			  }
			}
		  )
		  //Create a log file if the optional argument is true
		  if(report != false) {
			  logFile = new File(logFilePath +"\\"+ logTime()+".txt");
			  editedFiles = editedFiles + "End Time: " + endTime;
			  logFile.write(editedFiles);
		  }
		  println "$endTime Completed.\n"
	}
	
	
	// Method for getting the date for logging
	def logTime(){
		def date = new Date()
		def sdf = new SimpleDateFormat("MMddyyyy-HHmmss")
		return sdf.format(date)
	}
	
	// Method for getting the date for logging. Different Format
	def logTimeFormat(){
		def date = new Date()
		def sdf = new SimpleDateFormat("MMddyyyy-HH:mm:ss")
		return sdf.format(date)
	}
	
}
