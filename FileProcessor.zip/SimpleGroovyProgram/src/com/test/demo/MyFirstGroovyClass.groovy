package com.test.demo
import groovy.io.FileType
import java.text.SimpleDateFormat

class MyFirstGroovyClass{ 
	static void main(args) {
		// TODO Auto-generated method stub
	
		def myFileProccessor = new FileProccessor()
		//BASE DIRECTORY
		// **IMPORTANT** Directory of the Folder you want to process.
		def baseDirectory = "C:\\Users\\Darwin\\Desktop\\MyBaseDirectory\\"
		
		//Enter the word to be searched
		def srcExp = "Bear"
		
		//Replace the value of replaceText with the value new value to
		def replaceText = "Brisket"
		
		//Optional argument for the report 
		//NOTE: Add the "report" variable to ProcessFiles method as last parameter
		boolean report = true
		
		myFileProccessor.ProcessFiles(baseDirectory,srcExp,replaceText, report);
	}
}


